library ColorConstants;

import 'package:flutter/material.dart';

const mainColor = const Color(0xFFFB777A);
const btnColor = const Color(0xFFfb8385);
const textColor = const Color(0xFF000000);
const secTextColor = const Color(0xFFFFFFFF);

const card1 = const Color(0xFFFFBF37);
const card2 = const Color(0xFF00CECE);
const card3 = const Color(0xFFFB777A);
const card4 = const Color(0xFFA5A5A5);
